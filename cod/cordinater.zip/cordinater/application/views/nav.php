<body>  
<div id="container">  
    <div id="nav"> 
         
       <ul>  
           <?php foreach ($test as $key => $value) { ?>
          <li><a href="#"><?php echo $value ?></a></li>  
                   
              <?php } ?>
          
      </ul>  
    </div>  
