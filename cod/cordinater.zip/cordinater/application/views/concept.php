

<div id="concept"> 
     
        <h1>Welcome to my site</h1>  
        <p>CodeIgniter is PHP driven framework but it's not a PHP substitute.   
       Diving into CodeIgniter doesn?t mean you are leaving PHP behind.   
        PHP is a server-side scripting language for building dynamic web-based applications.</p>  
</div> 
