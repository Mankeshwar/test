

<div id="footer"> 

        <p>Copyright (c) 2016 ABWorld.com All Rights Reserved</p>  
    </div>  
  
</div>  
</body>  
</html>  
